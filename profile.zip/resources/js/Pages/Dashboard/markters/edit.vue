<template>
    <div>
      <p>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus recusandae sit optio cupiditate architecto aliquam at perferendis inventore minima doloribus impedit molestiae dolore fugiat, odit provident assumenda iusto? In, id.
      </p>  
    </div>
</template>