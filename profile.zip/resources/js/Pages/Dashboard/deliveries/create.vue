<template>
    <div>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur asperiores sequi ducimus qui deleniti. Soluta sit quasi alias nisi porro repudiandae, dolorem molestias eligendi totam numquam labore assumenda veniam nobis.
    </div>
</template>